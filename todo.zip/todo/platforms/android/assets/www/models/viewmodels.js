/**
* accountmodel Module
*
* Description
*/
var signupmodel = {
	
	phonenumber : '',
	password : '',
	gender : false
	

};
var loginmodel = {

	phonenumber: '',
	password: ''
	

};
var celebritymodel  = function(){
	var self = this;
	self.userName = '';
	self.firstName = '';
	self.lastName = '';
	self.email = '';
	self.location = '';
	self.bio = '';
	self.avatar = '';
	self.photo = '';
	self.dateJoined = '';
	
};

celebrity.prototype={
	getFanCount  : function(first_argument) {
	// body...
	},
	getName : function(){

	},
	getPic : function (){



	}



};

/*accountmodel.prototype = function(first_argument) {
	// body...
	recievetoken : function(){


	}
	validatetoken : function(){

	}
	

};*/



/*signupmodel.prototype = {
	/* body...
	recievetoken : function(){


	},
	validatetoken : function(){

	}
	

};*/