var trendingevent  = function(){
	var self = this;
	self.tile = '';
	self.venue =''
	self.location = '';
	self.photo = '';
	self.dateOfEvent = '';
	self.FanCount = 0;
	self.inventory = [];
};

trendingevent.prototype={
	getFanCount  : function(first_argument) {
	// body...
	},
	getName : function(){

	},
	getPic : function (){


		
	}



};
