var celebrity  = function(){
	var self = this;
	self.userName = '';
	self.firstName = '';
	self.lastName = '';
	self.email = '';
	self.location = '';
	self.bio = '';
	self.avatar = '';
	self.photo = '';
	self.dateJoined = '';
	
};

celebrity.prototype={
	getFanCount  : function(first_argument) {
	// body...
	},
	getName : function(){

	},
	getPic : function (){



	}



};
